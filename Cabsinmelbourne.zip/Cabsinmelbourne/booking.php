<?php
$url != 'https://cabinmelbourne.com.au/booking.php';

if ($_SERVER['HTTP_REFERER'] == $url) {
  header('Location: https://cabinmelbourne.com.au/'); //redirect to some other page
  exit();
}
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
//require '../vendor/autoload.php';
$errorMSG = "";


$name = $_POST["name"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$unitnumber = $_POST["unitnumber"];
$streetnumber = $_POST["streetnumber"];
$streetname = $_POST["streetname"];
$plocation = $_POST["plocation"];
$dlocation = $_POST["dlocation"];
$passengers = $_POST["passengers"];
$cab = $_POST["cab"];
$pdate = $_POST["pdate"];
$ptime = $_POST["ptime"];



$EmailTo = "arminder_kamboj@yahoo.com.au";
$Subject = "New Booking Ride by ".$_POST["name"];

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'Bcc:isjassal@gmail.com' . "\r\n";


// More headers
$headers .= 'From: Cab in melbourne <info@cabinmelbourne.com.au>' . "\r\n";
$headers .= 'Reply-To: '.$_POST['name'].'<'.$_POST['email'].'>' . "\r\n";

// prepare email body text
$body.= '<p>You have received new Booking Ride, following are the details:</p>';
$body.= '<strong>Name: </strong>'.$name.'<br />';
$body.= '<strong>Phone: </strong>'.$phone.'<br />';
$body.= '<strong>Email: </strong>'.$email.'<br />';
$body.= '<strong>Unit Number: </strong>'.$unitnumber.'<br />';
$body.= '<strong>Street Number: </strong>'.$streetnumber.'<br />';
$body.= '<strong>Street Name: </strong>'.$streetname.'<br />';
$body.= '<strong>Pick Up Location: </strong>'.$plocation.'<br />';
$body.= '<strong>Drop Off Location: </strong>'.$dlocation.'<br />';
$body.= '<strong>Passengers: </strong>'.$passengers.'<br />';
$body.= '<strong>Pick Up Date: </strong>'.$pdate.'<br />';
$body.= '<strong>Pick Up Time: </strong>'.$ptime.'<br />';
$success = mail($EmailTo, $Subject, $body, $headers);
// redirect to success page
if ($errorMSG == ""){
    
    $user_email_id = $_POST["email"];
	$usersubject = "Booking";
	$userheaders = "From: Cab in melbourne <info@cabinmelbourne.com.au>\n";
	$userheaders .= 'MIME-Version: 1.0' . "\r\n";
	$userheaders .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	

		$usermessage = "Dear " . $_POST['name'] . ", <br /> Thank You for Book Your Ride<br /><br />
This auto-reply is just to inform you that, we received your Booking for Our Service. Our driver representative will contact you soon.
<br /> <br />
		

Thank You,<br /><br />
Team Cab in melbourne <br />
<a href='https://cabinmelbourne.com.au/'>www.cabinmelbourne.com.au</a> <br />
	Phone:  +1 12345 67890, +1 67890 12345";
	mail($user_email_id,$usersubject,$usermessage,$userheaders);
   header("Location: https://cabinmelbourne.com.au/thankyou.html");
}else{
    if($errorMSG == ""){
        echo "Something went wrong :(";
    } else {
        echo $errorMSG;
    }
}

exit;
?>