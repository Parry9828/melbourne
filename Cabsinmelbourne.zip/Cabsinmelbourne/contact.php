<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errorMSG = "";

$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$unit_number = $_POST['unit_number'];
$snumber = $_POST['snumber'];
$stname = $_POST['stname'];
$picloc = $_POST['picloc'];
$date = $_POST['date'];
$time = $_POST['time'];
$passengers = $_POST['passengers'];
$droploc = $_POST['droploc'];
$message = $_POST['message'];


$EmailTo = "melbournesilvertaxicabs@gmail.com";
// $EmailTo = "preet907310@gmail.com";


// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'Cc: isjassal@gmail.com' . "\r\n";


// More headers
$headers .= 'Reply-To: ' . $_POST['email'] . '<' . $_POST['email'] . '>' . "\r\n";

$subject = "Booking Details";
$body = '<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <style type="text/css">body{width:650px;font-family:work-Sans,sans-serif;background-color:#f6f7fb;display:block}a{text-decoration:none}span{font-size:14px}p{font-size:15px;line-height:17px;letter-spacing:.5px;margin-top:0}.text-center{text-align:center}@media only screen and (max-width:768px){p{font-size:13px;line-height:15px;letter-spacing:.5px;margin-top:0}}</style>
</head>
    <body style="margin:30px auto">
        <table style="width:100%">
            <tbody>
                <tr>
                    <td>
                        <p><strong>Passenger Details</strong></p>
                        <table style="background-color:#f6f7fb;width:100%;">
                            <tbody>
                                <tr>
                                    <td>
                                        <table style="width:650px;margin:20px auto;background-color:#fff;border-radius:8px">
                                            <tbody>
                                                <tr>
                                                    <td style="padding:30px">
                                                        <p>Name : 
                                                            ' . $name . ',</p>
                                                        <p>Email :
                                                            ' . $email . '
                                                        </p>
                                                        <p>Phone :
                                                            ' . $phone . '
                                                        </p>
														<p>Unit Number/Street Number :
                                                            ' . $unit_number . ' 
                                                        </p>
													
                                                        <p>Street Name :
                                                            ' . $stname . '
                                                        </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <br/>
                        <p><strong>Pick Up Details</strong></p>
                        <table style="background-color:#f6f7fb;width:100%">
                            <tbody>
                                <tr>
                                    <td>
                                        <table style="width:650px;margin:20px auto;background-color:#fff;border-radius:8px">
                                            <tbody>
                                                <tr>
                                                    <td style="padding:30px">
                                                        <p>Pickup Location : 
                                                            ' . $picloc . ',</p>
                                                        <p>Passengers :
                                                            ' . $passengers . '
                                                        </p>
                                                        <p>Date :
                                                            ' . $date . '
                                                        </p>
														<p>Time :
                                                            ' . $time . '
                                                        </p>
														<p>Drop off Details :
                                                            ' . $droploc . '
                                                        </p>
                                                        <p>Message For Driver :
                                                            ' . $message . '
                                                        </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>';
$headers .= 'From: <no-reply@melbournesilvertaxicabs.com.au>' . "\r\n";

if (mail( $EmailTo, $subject, $body, $headers )) {

} else {
    echo ("Email sending failed...");
}


// mail($EmailTo, $Subject, $body, $headers);
if ($errorMSG == "") {

    $user_email_id = $_POST["email"];
    $usersubject = "Booking Details";
    $userheaders .= 'From: <no-reply@melbournesilvertaxicabs.com.au>' . "\r\n";
    $userheaders .= 'MIME-Version: 1.0' . "\r\n";
    $userheaders .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";


    $usermessage = ' <!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <style type="text/css">body{width:650px;font-family:work-Sans,sans-serif;background-color:#f6f7fb;display:block}a{text-decoration:none}span{font-size:14px}p{font-size:15px;line-height:17px;letter-spacing:.5px;margin-top:0}.text-center{text-align:center}@media only screen and (max-width:768px){p{font-size:13px;line-height:15px;letter-spacing:.5px;margin-top:0}}</style>
</head>
 <body style="margin:30px auto">
        <table style="width:100%">
            <tbody>
                <tr>
                    <td>
                            <table style="background-color:#f6f7fb;width:100%;">
                                <tbody>
                                    <tr>
                                        <td>
                                            <table style="width:650px;margin:20px auto;background-color:#fff;border-radius:8px">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding:30px">
                                                           <h2 style="text-align:center;">Thanks for sharing your details. Our Driver will Contact you Soon.</h2>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        <p><strong>Passenger Details</strong></p>
                        <table style="background-color:#f6f7fb;width:100%;">
                            <tbody>
                                <tr>
                                    <td>
                                        <table style="width:650px;margin:20px auto;background-color:#fff;border-radius:8px">
                                            <tbody>
                                                <tr>
                                                    <td style="padding:30px">
                                                        <p>Name : 
                                                            ' . $name . ',</p>
                                                        <p>Email :
                                                            ' . $email . '
                                                        </p>
                                                        <p>Phone :
                                                            ' . $phone . '
                                                        </p>
														<p>Unit Number/Street Number :
                                                            ' . $unit_number . ' 
                                                        </p>
														
                                                        <p>Street Name :
                                                            ' . $stname . '
                                                        </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <br/>
                        <p><strong>Pick Up Details</strong></p>
                        <table style="background-color:#f6f7fb;width:100%">
                            <tbody>
                                <tr>
                                    <td>
                                        <table style="width:650px;margin:20px auto;background-color:#fff;border-radius:8px">
                                            <tbody>
                                                <tr>
                                                    <td style="padding:30px">
                                                        <p>Pickup Location : 
                                                            ' . $picloc . ',</p>
                                                        <p>Passengers :
                                                            ' . $passengers . '
                                                        </p>
                                                        <p>Date :
                                                            ' . $date . '
                                                        </p>
														<p>Time :
                                                            ' . $time . '
                                                        </p>
														<p>Drop off Details :
                                                            ' . $droploc . '
                                                        </p>
                                                        <p>Message For Driver :
                                                            ' . $message . '
                                                        </p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </body>
</html>';
}
mail( $user_email_id, $usersubject, $usermessage, $userheaders );
header( "Location: https://melbournesilvertaxicabs.com.au/thankyou.html" );

?>